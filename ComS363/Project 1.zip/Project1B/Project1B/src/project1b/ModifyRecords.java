package project1b;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ModifyRecords {

	public static void main(String[] args) {
		String jdbcUrl = "jdbc:mysql://localhost:3306/project1b";
		String username = "coms363";
		String password = "password";
		String sql = "UPDATE STUDENTS SET name = 'Scott' WHERE ssn = 746897816";
		String sql1 = "UPDATE MAJOR SET name = 'Computer Science', level = 'MS' WHERE student_num IN (SELECT snum FROM STUDENTS "
				+ "WHERE ssn = 746897816)";


		try (Connection conn = DriverManager.getConnection(jdbcUrl, username, password); 
				Statement stmt = conn.createStatement();) {

			// 1)Change the name of the student with ssn = 746897816 to Scott
			stmt.executeUpdate(sql);
			System.out.println("Database updated successfully ");

			// 2)Change the major of the student with ssn = 746897816 to Computer Science, Master.
			stmt.executeUpdate(sql1);
			System.out.println("Database updated successfully ");

			// 3)Delete all registration records that were in �Spring2021�
			stmt.execute("DELETE FROM REGISTER WHERE regtime = 'Spring2021'");
			System.out.println("Database updated successfully ");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}