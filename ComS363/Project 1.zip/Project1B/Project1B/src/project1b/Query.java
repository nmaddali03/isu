package project1b;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
 
public class Query {
    public static void main(String[] args) {
        Connection connection = null;
        Statement selectStmt = null;
        try
        {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1b", "coms363", "password");
            selectStmt = connection.createStatement();
            
            // 1)The student number and ssn of the student whose name is "Becky"
            ResultSet rs = selectStmt.executeQuery("SELECT snum,ssn FROM students WHERE name = 'Becky'");
            while(rs.next())
            {
            	System.out.println("The student number and ssn of the student whose name is 'Becky'");
                System.out.println("snum " + rs.getString(1));    //First Column
                System.out.println("ssn " +rs.getString(2));    //Second Column
                System.out.println();
            }
            
            // 2)The major name and major level of the student whose ssn is 123097834
            ResultSet rs1 = selectStmt.executeQuery("SELECT name, level FROM MAJOR WHERE student_num IN (SELECT snum FROM STUDENTS WHERE ssn = 123097834)");
            while(rs1.next()) {
            	System.out.println("The major name and major level of the student whose ssn is 123097834");
            	System.out.println("name " + rs1.getString(1));
            	System.out.println("level "+rs1.getString(2));
                System.out.println();

            }
            
            // 3)The names of all courses offered by the department of Computer Science
            ResultSet rs2 = selectStmt.executeQuery("SELECT name, description FROM COURSES WHERE department_code IN (SELECT code FROM DEPARTMENTS "
            		+ "WHERE name = 'Computer Science')");
        	System.out.println("The names of all courses offered by the department of Computer Science");
            while(rs2.next()) {
            	System.out.println("name "+rs2.getString(1));
            	System.out.println("description "+rs2.getString(2));
                System.out.println();
            }

            // 4)All degree names and levels offered by the department Computer Science
            ResultSet rs3 = selectStmt.executeQuery("SELECT name, level FROM DEGREES WHERE department_code IN (SELECT code FROM DEPARTMENTS WHERE name = 'Computer Science')");
        	System.out.println("All degree names and levels offered by the department Computer Science");
        	while(rs3.next()) {
            	System.out.println("name "+rs3.getString(1));
            	System.out.println("level "+rs3.getString(2));
                System.out.println();
            }
        	
        	// 5)The names of all students who have a minor
            ResultSet rs4 = selectStmt.executeQuery("SELECT name FROM STUDENTS WHERE snum IN (SELECT student_num FROM MINOR)");
        	System.out.println("The names of all students who have a minor");
        	while(rs4.next()) {
            	System.out.println("name "+rs4.getString(1));
            }
        } 
        catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                //selectStmt.close();
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
