package project1b;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CreateTables {

	private static final String CREATE_TABLE_SQL="CREATE TABLE IF NOT EXISTS students ("
			+ "snum INT,"
			+ "ssn INT,"
			+ "name VARCHAR(10) NOT NULL,"
			+ "gender VARCHAR(1) NOT NULL,"
			+ "dob DATETIME NOT NULL,"
			+ "c_addr VARCHAR(20),"
			+ "c_phone VARCHAR(10),"
			+ "p_addr VARCHAR(20),"
			+ "p_phone VARCHAR(10),"
			+ "PRIMARY KEY (ssn),"
			+ "UNIQUE (snum))";     
	private static final String CREATE_TABLE_SQL1="CREATE TABLE IF NOT EXISTS departments ("
			+ "code INT,"
			+ "name VARCHAR(50),"
			+ "phone VARCHAR(10),"
			+ "college VARCHAR(20),"
			+ "PRIMARY KEY (code),"
			+ "UNIQUE (name))";  
	private static final String CREATE_TABLE_SQL2="CREATE TABLE IF NOT EXISTS degrees ("
			+ "name VARCHAR(50),"
			+ "level VARCHAR(5),"
			+ "department_code INT,"
			+ "PRIMARY KEY (name, level),"
			+ "FOREIGN KEY (department_code) REFERENCES DEPARTMENTS(code) ON DELETE CASCADE)"; 
	private static final String CREATE_TABLE_SQL3="CREATE TABLE IF NOT EXISTS courses ("
			+ "number INT,"
			+ "name VARCHAR(50),"
			+ "description VARCHAR(50),"
			+ "credithours INT,"
			+ "level VARCHAR(20),"
			+ "department_code INT,"
			+ "PRIMARY KEY (number),"
			+ "UNIQUE (name),"
			+ "FOREIGN KEY (department_code) REFERENCES DEPARTMENTS(CODE))"; 
	private static final String CREATE_TABLE_SQL4="CREATE TABLE IF NOT EXISTS register ("
			+ "snum INT,"
			+ "course_number INT,"
			+ "regtime VARCHAR(20),"
			+ "grade INT,"
			+ "PRIMARY KEY (snum, course_number),"
			+ "FOREIGN KEY (snum) REFERENCES STUDENTS(snum) ON DELETE CASCADE,"
			+ "FOREIGN KEY (course_number) REFERENCES COURSES(number) ON DELETE CASCADE)"; 
	private static final String CREATE_TABLE_SQL5="CREATE TABLE IF NOT EXISTS major ("
			+ "student_num INT,"
			+ "name VARCHAR(50),"
			+ "level VARCHAR(5),"
			+ "PRIMARY KEY (student_num, name, level),"
			+ "FOREIGN KEY (student_num) REFERENCES STUDENTS(snum) ON DELETE CASCADE,"
			+ "FOREIGN KEY (name, level) REFERENCES DEGREES(name,level) ON DELETE CASCADE)"; 
	private static final String CREATE_TABLE_SQL6="CREATE TABLE IF NOT EXISTS minor ("
			+ "student_num INT,"
			+ "name VARCHAR(50),"
			+ "level VARCHAR(5),"
			+ "PRIMARY KEY (student_num, name, level),"
			+ "FOREIGN KEY (student_num) REFERENCES STUDENTS(snum) ON DELETE CASCADE,"
			+ "FOREIGN KEY (name, level) REFERENCES DEGREES(name,level) ON DELETE CASCADE)";   

	public static void main(String[] args) {
		String jdbcUrl = "jdbc:mysql://localhost:3306/project1b";
		String username = "coms363";
		String password = "password";

		Connection conn = null;
		PreparedStatement stmt = null;

		try {

			conn = DriverManager.getConnection(jdbcUrl, username, password);

			stmt = conn.prepareStatement(CREATE_TABLE_SQL);
			stmt.executeUpdate();
			stmt = conn.prepareStatement(CREATE_TABLE_SQL1);
			stmt.executeUpdate();
			stmt = conn.prepareStatement(CREATE_TABLE_SQL2);
			stmt.executeUpdate();
			stmt = conn.prepareStatement(CREATE_TABLE_SQL3);
			stmt.executeUpdate();
			stmt = conn.prepareStatement(CREATE_TABLE_SQL4);
			stmt.executeUpdate();
			stmt = conn.prepareStatement(CREATE_TABLE_SQL5);
			stmt.executeUpdate();
			stmt = conn.prepareStatement(CREATE_TABLE_SQL6);
			stmt.executeUpdate();

			System.out.println("Tables created");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
