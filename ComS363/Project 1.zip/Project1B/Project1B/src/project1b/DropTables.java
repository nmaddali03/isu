package project1b;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DropTables {
	static final String DB_URL = "jdbc:mysql://localhost/project1b";
	static final String USER = "coms363";
	static final String PASS = "password";

	public static void main(String[] args) {
		// Open a connection
		try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
				Statement stmt = conn.createStatement();
				) {		      
			String sql = "DROP TABLE register";
			stmt.executeUpdate(sql);
			String sql1 = "DROP TABLE courses";
			stmt.executeUpdate(sql1);
			String sql2 = "DROP TABLE major";
			stmt.executeUpdate(sql2); 
			String sql3 = "DROP TABLE minor";
			stmt.executeUpdate(sql3); 
			String sql4 = "DROP TABLE degrees";
			stmt.executeUpdate(sql4); 
			String sql5 = "DROP TABLE departments";
			stmt.executeUpdate(sql5);
			String sql6 = "DROP TABLE students";
			stmt.executeUpdate(sql6);
			System.out.println("Tables deleted in given database...");   	  
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
}