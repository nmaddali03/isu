/*Neha Maddali ComS363 Project 1A*/
USE project1;

/*1) Change the name of the student with ssn = 746897816 to Scott*/
UPDATE STUDENTS SET name = "Scott" WHERE ssn = 746897816;

/*2) Change the major of the student with ssn = 746897816 to Computer Science, Master*/
UPDATE MAJOR SET name = "Computer Science", level = "MS" WHERE student_num IN (SELECT snum FROM STUDENTS 
WHERE ssn = 746897816);

/*3) Delete all registration records that were in “Spring2021”*/
DELETE FROM REGISTER WHERE regtime = "Spring2021";