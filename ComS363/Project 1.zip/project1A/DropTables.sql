/*Neha Maddali ComS363 Project 1A*/
USE project1;

SET FOREIGN_KEY_CHECKS=OFF;
DROP TABLE courses, degrees, departments, major, minor, register, students;