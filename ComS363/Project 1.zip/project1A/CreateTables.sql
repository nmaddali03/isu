/*Neha Maddali ComS363 Project 1A*/
CREATE database project1;
USE project1;

CREATE TABLE students(
	snum INT,
    ssn INT,
    name VARCHAR(10) NOT NULL,
    gender VARCHAR(1) NOT NULL,
    dob DATETIME NOT NULL,
    c_addr VARCHAR(20),
    c_phone VARCHAR(10),
    p_addr VARCHAR(20),
    p_phone VARCHAR(10),
    PRIMARY KEY (ssn),
    UNIQUE (snum)    
);

CREATE TABLE IF NOT EXISTS departments (
	code INT,
	name VARCHAR(50),
	phone VARCHAR(10),
	college VARCHAR(20),
	PRIMARY KEY (code),
	UNIQUE (name)
);

CREATE TABLE IF NOT EXISTS degrees(
	name VARCHAR(50),
    level VARCHAR(5),
    department_code INT,
    PRIMARY KEY (name, level),
    FOREIGN KEY (department_code) REFERENCES DEPARTMENTS(code) ON DELETE CASCADE /*Note: department_code refers to code in table departments*/
);

CREATE TABLE courses(
	number INT,
    name VARCHAR(50),
    description VARCHAR(50),
    credithours INT,
    level VARCHAR(20),
    department_code INT,
    PRIMARY KEY (number),
    UNIQUE (name),
    FOREIGN KEY (department_code) REFERENCES DEPARTMENTS(CODE) /*Note: department_code refers to code in table departments*/
);

CREATE TABLE register(
	snum INT,
    course_number INT,
    regtime VARCHAR(20),
    grade INT,
    PRIMARY KEY (snum, course_number),
    FOREIGN KEY (snum) REFERENCES STUDENTS(snum), /*Note: snum refers to snum in table students*/
    FOREIGN KEY (course_number) REFERENCES COURSES(number) /*Note: course_number refers to number in table courses*/
);

CREATE TABLE IF NOT EXISTS major(student_num INT,
    name VARCHAR(50),
    level VARCHAR(5),
    PRIMARY KEY (student_num, name, level),
    FOREIGN KEY (student_num) REFERENCES STUDENTS(snum) ON DELETE CASCADE,
    FOREIGN KEY (name, level) REFERENCES DEGREES(name,level) ON DELETE CASCADE /*Note: name refers to name in table degrees*/
    /*FOREIGN KEY (level) REFERENCES DEGREES(level) ON DELETE CASCADE Note: level refers to level in table degrees*/
);

CREATE TABLE IF NOT EXISTS minor(student_num INT,
    name VARCHAR(50),
    level VARCHAR(5),
	PRIMARY KEY (student_num, name, level),
    FOREIGN KEY (student_num) REFERENCES STUDENTS(snum) ON DELETE CASCADE,
    FOREIGN KEY (name, level) REFERENCES DEGREES(name,level) ON DELETE CASCADE /*Note: name refers to name in table degrees*/
    /*FOREIGN KEY (level) REFERENCES DEGREES(level) ON DELETE CASCADE/*Note: level refers to level in table degrees*/
);
