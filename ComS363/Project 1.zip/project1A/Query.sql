/*Neha Maddali ComS363 Project 1A*/
USE project1;

/*1) The student number and ssn of the student whose name is "Becky"*/
SELECT snum, ssn FROM STUDENTS WHERE name = "Becky"; 

/*2) The major name and major level of the student whose ssn is 123097834*/
SELECT name, level FROM MAJOR WHERE student_num IN (SELECT snum FROM STUDENTS WHERE ssn = 123097834);

/*3) The names of all courses offered by the department of Computer Science*/
SELECT name, description FROM COURSES WHERE department_code IN (SELECT code FROM DEPARTMENTS
WHERE name = "Computer Science");

/*4) All degree names and levels offered by the department Computer Science*/
SELECT name, level FROM DEGREES WHERE department_code IN (SELECT code FROM DEPARTMENTS WHERE name = "Computer Science");

/*5) The names of all students who have a minor*/
SELECT name FROM STUDENTS WHERE snum IN (SELECT student_num FROM MINOR);

/*6) The number of students who have a minor*/
SELECT COUNT(*) FROM MINOR;

/*7) The names and snums of all students enrolled in course “Algorithm”*/
SELECT name, snum FROM STUDENTS WHERE snum IN (SELECT snum FROM REGISTER WHERE course_number IN 
(SELECT number FROM COURSES WHERE name = "Algorithm"));

/*8) The name and snum of the oldest student*/
SELECT name, snum FROM STUDENTS WHERE dob = (SELECT MIN(dob) FROM STUDENTS);

/*9) The name and snum of the youngest student*/
SELECT name, snum FROM STUDENTS WHERE dob = (SELECT MAX(dob) FROM STUDENTS);

/*10) The name, snum and SSN of the students whose name contains letter “n” or “N”*/
SELECT name, snum, ssn FROM STUDENTS WHERE name LIKE '%n%' OR 'N%';

/*11) The name, snum and SSN of the students whose name does not contain letter “n” or “N”*/
SELECT name, snum, ssn FROM STUDENTS WHERE name NOT LIKE '%n%' OR 'N%';

/*12) The course number, name and the number of students registered for each course*/
SELECT distinct number, name, COUNT(snum) FROM COURSES, REGISTER WHERE number = course_number GROUP BY number;

/*13) The name of the students enrolled in Fall2020 semester.*/
SELECT name FROM STUDENTS WHERE snum IN (SELECT snum FROM REGISTER WHERE regtime = "Fall2020");

/*14) The course numbers and names of all courses offered by Department of Computer Science*/
SELECT number, name FROM COURSES WHERE department_code IN (SELECT code FROM DEPARTMENTS WHERE name = "Computer Science");

/*15) The course numbers and names of all courses offered by either Department of Computer Science or Department of Landscape Architect*/
SELECT number, name FROM COURSES WHERE department_code IN (SELECT code FROM DEPARTMENTS WHERE 
name = "Computer Science" OR name = "Landscape Architect");



