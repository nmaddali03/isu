/*Neha Maddali ComS363 Project 3-3*/
USE project3;

/*List k=5 most retweeted tweets in a given month = 1 and a given year = 2016; show the retweet count, the tweet text, the posting 
user’s screen name, the posting user’s category, the posting user’s sub-category in descending order of the retweet count values */
SELECT t.retweet_count, t.textbody, u.screen_name, u.category, u.sub_category
FROM Tweet t INNER JOIN `TwitterUser` u ON t.posting_user = u.screen_name
WHERE t.month_posted = 1 AND t.year_posted = 2016 ORDER BY t.retweet_count DESC LIMIT 5;

/*Find k=5 hashtags that appeared in the most number of states in a given year = 2016; list the total number of states the hashtag 
appeared, the list of the distinct states it appeared (FL is the same as Florida*), and the hashtag itself in descending order of the 
number of states the hashtag appeared.*/
SELECT COUNT(DISTINCT state) as statenum, GROUP_CONCAT(DISTINCT state) as states, hashtagname
FROM tagged ta JOIN Tweet tw ON ta.tid = tw.tid JOIN `TwitterUser` u ON tw.posting_user = u.screen_name
where tw.year_posted = 2016 AND state <> 'na' GROUP BY hashtagname ORDER BY COUNT(DISTINCT state) DESC LIMIT 5;

/*Find k=12 users who used at least one of the hashtags in a given list of hashtags = [HappyNewYear,NewYear,NewYears,NewYearsDay] in 
their tweets. Show the user’s screen name and the state the user lives in descending order of the number of this user’s followers. */
SELECT u.screen_name, u.state FROM Tagged t JOIN Tweet n ON t.tid = n.tid JOIN TwitterUser u ON n.posting_user = u.`name`
WHERE t.hashtagname IN ('HappyNewYear' , 'NewYear', 'NewYears', 'NewYearsDay')
GROUP BY u.screen_name ORDER BY u.numFollowers DESC LIMIT 12;

/*Find top k=5 most followed users in a given party. Show the user’s screen name, the user’s party, and the number of followers 
in descending order of the number of followers. Show your results with subcategory to be 'GOP' and 'Democrat' separately.  */
SELECT screen_name, sub_category, numFollowers FROM TwitterUser u
WHERE sub_category = 'GOP' ORDER BY numFollowers DESC LIMIT 5;

SELECT screen_name, sub_category, numFollowers FROM TwitterUser u
WHERE sub_category = 'Democrat' ORDER BY numFollowers DESC LIMIT 5;

/*Find the list of distinct hashtags that appeared in one of the states in a given list = [Ohio, Alaska, Alabama] in a given month = 1 
of a given year = 2016; show the list of the hashtags and the names of the states in which they appeared. */
SELECT distinct hashtagname, state FROM Tagged ta JOIN Tweet tw ON ta.tid = tw.tid JOIN
TwitterUser twu ON tw.posting_user = twu.screen_name WHERE state in ('Ohio', 'Alaska', 'Alabama') and month_posted=1 and
year_posted=2016 order by hashtagname;

/*Find k=5 tweets (with the given hashtag = Ohio) posted by republican (GOP) or democrat members of a given state = Ohio in a given 
month = 1 of a given year = 2016. Show the tweet text, the hashtag, the screen name of the posting user, and the users’ party */
SELECT n.textbody, t.hashtagname, u.screen_name,u.sub_category
FROM Tagged t JOIN Tweet n ON t.tid = n.tid JOIN twitteruser u ON n.posting_user = u.screen_name
WHERE t.hashtagname = 'ohio' AND (u.sub_category = 'democrat' OR u.sub_category = 'gop') AND n.month_posted = 1 AND n.year_posted = 2016
LIMIT 5;

/*Find users in a given sub-category = ‘GOP’ along with the list of URLs used in the user’s tweets in a given month = 1 of a 
given year = 2016. Show the user’s screen name, the state the user lives, and the list of URLs */
SELECT u.screen_name, u.state, GROUP_CONCAT(ur.url) AS URLs FROM URL ur JOIN Tweet n ON ur.tid = n.tid JOIN TwitterUser u 
ON u.screen_name = n.posting_user WHERE u.sub_category = 'GOP' AND n.month_posted = 1 AND n.year_posted = 2016 GROUP BY u.screen_name
ORDER BY n.posting_user;

/*Find k=5 users who were mentioned the most in tweets of users of a given party = ‘GOP’ in a given month = 1 of a given year = 2016. 
Show the user’s screen name, user’s state, and the list of the screen name of the user(s) who mentioned this user in descending order 
of the number of tweets mentioning this user. */
SELECT m.screen_name AS mentionedUser, u2.state, GROUP_CONCAT(DISTINCT t.posting_user) FROM mentioned m INNER JOIN Tweet t USING (tid) JOIN 
TwitterUser u ON t.posting_user = u.screen_name JOIN TwitterUser u2 ON m.screen_name = u2.screen_name WHERE u.sub_category = 'GOP' AND 
t.month_posted = 1 AND t.year_posted = 2016 GROUP BY m.screen_name ORDER BY COUNT(t.tid) DESC LIMIT 5;

/*Find k=5 most used hashtags with the count of tweets it appeared posted by a given sub-category = ‘GOP’ of users in a list of 
months = [1, 2, 3] of a given year = 2016. Show the hashtag name and the count in descending order of the count. */
SELECT t.hashtagname, COUNT(tid) FROM Tagged t JOIN Tweet n USING (tid) JOIN TwitterUser u ON n.posting_user = u.screen_name
WHERE u.sub_category = 'GOP' AND n.month_posted IN (1 , 2, 3) AND n.year_posted = 2016 GROUP BY t.hashtagname ORDER BY COUNT(tid) DESC
LIMIT 5;




