/*Neha Maddali ComS363 Project 3-2*/
CREATE DATABASE IF NOT EXISTS project3;
USE project3;

CREATE TABLE IF NOT EXISTS Tweet(
	`tid` bigint NOT NULL,
     textbody varchar(240),
     retweet_count int,
     retweeted int,
     month_posted int,
     day_posted int,
     year_posted int,
     posting_user varchar(25),
     PRIMARY KEY (tid)
);

CREATE TABLE IF NOT EXISTS TwitterUser(
	screen_name varchar(25),
    name varchar (50),
    sub_category varchar (25),
    category varchar (25),
    state varchar (50),
    numFollowers int,
    numFollowing int,
    PRIMARY KEY (screen_name)
);

CREATE TABLE IF NOT EXISTS Mentioned(
	`tid` bigint NOT NULL,
	mentioned_id int NOT NULL AUTO_INCREMENT,
	screen_name varchar(25),
	PRIMARY KEY (mentioned_id),
	FOREIGN KEY (screen_name) REFERENCES TwitterUser (screen_name)
);

CREATE TABLE IF NOT EXISTS Tagged(
	`tid` bigint,
	tag_id int NOT NULL AUTO_INCREMENT,
	hashtagname varchar(50) ,
	PRIMARY KEY (tag_id),
	FOREIGN KEY (tid) REFERENCES Tweet (tid) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS URL(
	`tid` bigint NOT NULL,
	url varchar(500),
	url_id int NOT NULL AUTO_INCREMENT,
	PRIMARY KEY (url_id),
	FOREIGN KEY (tid) REFERENCES Tweet (tid) ON DELETE CASCADE
);