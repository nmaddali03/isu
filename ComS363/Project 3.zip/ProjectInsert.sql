/*Neha Maddali ComS363 Project 3-2*/
Use project3;
SET GLOBAL local_infile = 'ON';  

LOAD DATA LOCAL INFILE '/Users/neham/Downloads/project3/dataCSV/tweets.csv' 
INTO TABLE Tweet
FIELDS TERMINATED BY ';' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(tid,@col2,@col3,@col4,@col5,posting_user)
set day_posted= day(str_to_date(@col5, '%Y-%m-%d %H:%i:%s')), 
month_posted= month(str_to_date(@col5, '%Y-%m-%d %H:%i:%s')), 
year_posted= year(str_to_date(@col5, '%Y-%m-%d %H:%i:%s')),
textbody = @col2,
retweet_count = @col3,
retweeted = @col4;

LOAD DATA LOCAL INFILE '/Users/neham/Downloads/project3/dataCSV/user.csv' 
INTO TABLE twitteruser
FIELDS TERMINATED BY ';' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(screen_name, name, sub_category, category, state, numFollowers, numFollowing);

LOAD DATA LOCAL INFILE '/Users/neham/Downloads/project3/dataCSV/mentioned.csv' 
INTO TABLE mentioned
FIELDS TERMINATED BY ';' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(tid, screen_name);

LOAD DATA LOCAL INFILE '/Users/neham/Downloads/project3/dataCSV/tagged.csv' 
INTO TABLE tagged
FIELDS TERMINATED BY ';' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(tid, hashtagname);

LOAD DATA LOCAL INFILE '/Users/neham/Downloads/project3/dataCSV/urlused.csv' 
INTO TABLE url
FIELDS TERMINATED BY ';' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(tid, url);





