#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void fuzzMe(int a, int b, char *c){
        printf("%d, %d, %s\n", a, b, c);
        if (a >= 20000){
                if (b >= 10000000){
                        if (b - a < 200){
                                free(c);
                                char *s = (char *)malloc(strlen("some random text") + 1);
                                strcpy(s, "some random text");
                                printf("%s\n", s);
                                }
                        else{
                                if (strlen(c) < 7) {
                                        char *s = (char *)malloc(1);
                                        strcpy(s, "some random text");
                                        printf("%s\n", s);
                                }
                        }
                }
        }
}

int main(int argc, char *argv[]){
        int a, b;
        char str[1000];
        scanf("%d %d %s", &a, &b, str);
        fuzzMe(a, b, str);
}