#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void fuzzMe(int a, int b, char *c){
	    printf("%d ,%d ,%s", a, b, c);
	        if (a >= 20000){
			        if (b >= 10000000){
					            if (b - a < 200){
							                    free(c);
									                    char *s = (char *)malloc(strlen("some random text") + 1);
											                    strcpy(s, "some random text");
													                    printf("%s", s);
															                }else{
																		                if (strlen(c) < 7) {
																					                    char *s = (char *)malloc(1);
																							                        strcpy(s, "some random text");
																										                    printf("%s", s);
																												                    }
																				            }
						            }
				    }
}

int main(int argc, char *argv[]){
	    int a, b;
	        char str[1000];
		    klee_make_symbolic(&a, sizeof(a), "a");
		        klee_make_symbolic(&b, sizeof(b), "b");
			    klee_make_symbolic(str, sizeof(str), "str");
			        fuzzMe(a, b, str);
}


