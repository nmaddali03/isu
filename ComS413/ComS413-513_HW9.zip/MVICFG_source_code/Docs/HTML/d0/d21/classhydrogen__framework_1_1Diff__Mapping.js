var classhydrogen__framework_1_1Diff__Mapping =
[
    [ "Diff_Mapping", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#af90c30478b210b35ec2872766b1f0761", null ],
    [ "~Diff_Mapping", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a10aabc7098c63892b13e13d7a87dc1b9", null ],
    [ "getAddedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a3febde10ce387d410bf97d9d2b3e3f1f", null ],
    [ "getAfterLineNumber", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a4326f5b36e7bc06e3fd4410d399d6c41", null ],
    [ "getBeforeLineNumber", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#ae9f45495f5f3d03365cb9303424503e7", null ],
    [ "getDeletedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a9319e5ba9266687afa0409cbc840fc87", null ],
    [ "getFileName", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#aa478ea59c018a81e417a816d10ceb9fe", null ],
    [ "getMapping", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#aff1a3e4d1d4f214cacb85c145f02b94f", null ],
    [ "getMatchedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a11135a89cdee7b239f378fdd01838f8a", null ],
    [ "printAddedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#aca01ed12bdbad8101fbb489e9b9595b6", null ],
    [ "printDeletedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#ad2360584c6e4e766111614c8be2e5abc", null ],
    [ "printFileInfo", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#abcb455f072c2c77407e266fc6cb38d55", null ],
    [ "printMapping", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#abc3fa345de74e344305697f788ac069a", null ],
    [ "printMatchedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#ad6e3a5abe47f7449dfe496a1bfe8f422", null ],
    [ "putMapping", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a034639efedc0bddd31b06669739bdd63", null ],
    [ "addedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a9c73e78ce359f3112b683cffcf0ef07a", null ],
    [ "deletedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a2a72b1628050f14e27356f28274829c2", null ],
    [ "fileName", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a5c6d7e9cce3af2eb7228a6122e2f2ddb", null ],
    [ "lineMap", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a6a63c7ecf4077dd644862fc4d4e57871", null ],
    [ "matchedLines", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a463f63d7e645a004d8241e8fdc56412c", null ]
];