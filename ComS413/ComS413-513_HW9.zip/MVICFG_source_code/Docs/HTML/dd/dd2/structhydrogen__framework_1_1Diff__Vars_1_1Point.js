var structhydrogen__framework_1_1Diff__Vars_1_1Point =
[
    [ "k", "dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point.html#a86fbc9b8839cf398189c494b8eaf0639", null ],
    [ "x", "dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point.html#ab4ab9b946797cd8002f9d90d6fd0aa68", null ],
    [ "y", "dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point.html#ac23facb3c130410f6889022446c0370a", null ]
];