var structhydrogen__framework_1_1Diff__Vars_1_1eleminfo =
[
    [ "operator==", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html#ae920cece865b1c2da39c32e1001700fd", null ],
    [ "afterIdx", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html#ad221ad7ded41d66c10378ffb48893a66", null ],
    [ "beforeIdx", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html#ab5d4b64261b961877cfd4a6d8db03467", null ],
    [ "type", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html#a8f294dc63050952408206c8e172c531f", null ]
];