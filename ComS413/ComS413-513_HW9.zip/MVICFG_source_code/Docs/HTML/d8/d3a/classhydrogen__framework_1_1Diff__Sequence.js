var classhydrogen__framework_1_1Diff__Sequence =
[
    [ "Diff_Sequence", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence.html#a630ce92ef8577c83a5ae905dc2615df9", null ],
    [ "~Diff_Sequence", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence.html#ab0c4ff67fbe0fbdd99e140b03d10f6d6", null ],
    [ "addSequence", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence.html#a3f0335f88e67d3df3cbdf1e52878d2c7", null ],
    [ "getSequence", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence.html#a12d5167dc260155cfc57e91893ef5c85", null ],
    [ "sequence", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence.html#a07b0ba2b683dab0b53e9ce37bac2bb05", null ]
];