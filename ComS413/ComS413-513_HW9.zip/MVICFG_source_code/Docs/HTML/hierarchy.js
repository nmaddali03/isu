var hierarchy =
[
    [ "hydrogen_framework::Diff_Compare", "d1/d32/classhydrogen__framework_1_1Diff__Compare.html", null ],
    [ "hydrogen_framework::Diff_Vars", "d3/db1/classhydrogen__framework_1_1Diff__Vars.html", [
      [ "hydrogen_framework::Diff_Mapping", "d0/d21/classhydrogen__framework_1_1Diff__Mapping.html", null ],
      [ "hydrogen_framework::Diff_Sequence", "d8/d3a/classhydrogen__framework_1_1Diff__Sequence.html", [
        [ "hydrogen_framework::Diff_Ses", "d1/d16/classhydrogen__framework_1_1Diff__Ses.html", null ]
      ] ],
      [ "hydrogen_framework::Diff_Util", "d2/d24/classhydrogen__framework_1_1Diff__Util.html", null ]
    ] ],
    [ "hydrogen_framework::Diff_Vars::eleminfo", "d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html", null ],
    [ "hydrogen_framework::Diff_Vars::Point", "dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point.html", null ],
    [ "hydrogen_framework::Graph", "d4/d7a/classhydrogen__framework_1_1Graph.html", null ],
    [ "hydrogen_framework::Graph_Edge", "d2/d64/classhydrogen__framework_1_1Graph__Edge.html", null ],
    [ "hydrogen_framework::Graph_Function", "dc/d7a/classhydrogen__framework_1_1Graph__Function.html", null ],
    [ "hydrogen_framework::Graph_Instruction", "da/df5/classhydrogen__framework_1_1Graph__Instruction.html", null ],
    [ "hydrogen_framework::Graph_Line", "d8/d0b/classhydrogen__framework_1_1Graph__Line.html", null ],
    [ "hydrogen_framework::Hydrogen", "df/d43/classhydrogen__framework_1_1Hydrogen.html", null ],
    [ "hydrogen_framework::Module", "da/d32/classhydrogen__framework_1_1Module.html", null ]
];