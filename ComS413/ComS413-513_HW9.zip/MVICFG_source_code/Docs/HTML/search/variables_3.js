var searchData=
[
  ['deletedlines',['deletedLines',['../d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a2a72b1628050f14e27356f28274829c2',1,'hydrogen_framework::Diff_Mapping']]],
  ['deletesfirst',['deletesFirst',['../d1/d16/classhydrogen__framework_1_1Diff__Ses.html#aa5e90a29bb7d325a4f720637c278e258',1,'hydrogen_framework::Diff_Ses']]],
  ['delta',['delta',['../d2/d24/classhydrogen__framework_1_1Diff__Util.html#a5b5dde0a50206d59df342ed011ba02cc',1,'hydrogen_framework::Diff_Util']]]
];
