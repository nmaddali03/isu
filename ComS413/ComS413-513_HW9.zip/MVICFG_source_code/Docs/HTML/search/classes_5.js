var searchData=
[
  ['point',['Point',['../dd/dd2/structhydrogen__framework_1_1Diff__Vars_1_1Point.html',1,'hydrogen_framework::Diff_Vars']]]
];
