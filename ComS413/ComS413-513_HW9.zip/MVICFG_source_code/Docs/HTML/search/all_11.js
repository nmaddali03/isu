var searchData=
[
  ['type',['type',['../d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html#a8f294dc63050952408206c8e172c531f',1,'hydrogen_framework::Diff_Vars::eleminfo']]]
];
