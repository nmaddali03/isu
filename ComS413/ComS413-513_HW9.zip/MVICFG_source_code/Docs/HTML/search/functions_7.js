var searchData=
[
  ['impl',['impl',['../d1/d32/classhydrogen__framework_1_1Diff__Compare.html#a0ca27f55c1d86275e679b5b2c89e8e14',1,'hydrogen_framework::Diff_Compare']]],
  ['init',['init',['../d2/d24/classhydrogen__framework_1_1Diff__Util.html#aaa4a1e42178feb443d6d7a2740b462fa',1,'hydrogen_framework::Diff_Util']]],
  ['insertinstructionvisitedqueries',['insertInstructionVisitedQueries',['../da/df5/classhydrogen__framework_1_1Graph__Instruction.html#a398bca5a96af1c5e5c0e48a71a7d7316',1,'hydrogen_framework::Graph_Instruction']]],
  ['ischange',['isChange',['../d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ac10503e86638589e9b7446cf3577e01e',1,'hydrogen_framework::Diff_Ses']]],
  ['isfunctionfileset',['isFunctionFileSet',['../dc/d7a/classhydrogen__framework_1_1Graph__Function.html#a93e8d98817ca7781c9e1e19ec143f5dd',1,'hydrogen_framework::Graph_Function']]],
  ['isfunctionlinesempty',['isFunctionLinesEmpty',['../dc/d7a/classhydrogen__framework_1_1Graph__Function.html#afd6f5f0673e0139498c412858262c046',1,'hydrogen_framework::Graph_Function']]],
  ['islineinstructionempty',['isLineInstructionEmpty',['../d8/d0b/classhydrogen__framework_1_1Graph__Line.html#a6d5dfabc11192a34ab352f84294ae5d5',1,'hydrogen_framework::Graph_Line']]],
  ['isonlyadd',['isOnlyAdd',['../d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ae54607b1f89be5b184184e1d68d8b23d',1,'hydrogen_framework::Diff_Ses']]],
  ['isonlycopy',['isOnlyCopy',['../d1/d16/classhydrogen__framework_1_1Diff__Ses.html#a1c9e213ee78906eb104ab92e5c385999',1,'hydrogen_framework::Diff_Ses']]],
  ['isonlydelete',['isOnlyDelete',['../d1/d16/classhydrogen__framework_1_1Diff__Ses.html#a5d41ea9f3fcbe5f571195350eba8221d',1,'hydrogen_framework::Diff_Ses']]],
  ['isonlyoneoperation',['isOnlyOneOperation',['../d1/d16/classhydrogen__framework_1_1Diff__Ses.html#ae859a3907950e5e92593369846331962',1,'hydrogen_framework::Diff_Ses']]],
  ['ispartofgraph',['isPartOfGraph',['../d2/d64/classhydrogen__framework_1_1Graph__Edge.html#aec36a6939daf95cc445ced75df1dad71',1,'hydrogen_framework::Graph_Edge']]],
  ['isvirtualnodelinenumber',['isVirtualNodeLineNumber',['../d4/d7a/classhydrogen__framework_1_1Graph.html#a3f18eb16e6ee20b9bfb19933aaab48df',1,'hydrogen_framework::Graph']]]
];
