var searchData=
[
  ['a',['A',['../d2/d24/classhydrogen__framework_1_1Diff__Util.html#a3fb71773845193f3c06e174384d8096d',1,'hydrogen_framework::Diff_Util']]],
  ['addedlines',['addedLines',['../d0/d21/classhydrogen__framework_1_1Diff__Mapping.html#a9c73e78ce359f3112b683cffcf0ef07a',1,'hydrogen_framework::Diff_Mapping']]],
  ['afteridx',['afterIdx',['../d8/d86/structhydrogen__framework_1_1Diff__Vars_1_1eleminfo.html#ad221ad7ded41d66c10378ffb48893a66',1,'hydrogen_framework::Diff_Vars::eleminfo']]]
];
