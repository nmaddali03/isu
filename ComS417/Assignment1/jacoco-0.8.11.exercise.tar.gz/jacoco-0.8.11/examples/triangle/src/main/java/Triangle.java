//Introduction to Software Testing
//Authors: Paul Ammann & Jeff Offutt
//Chapter 6;
// See TriangleTypeTest for Junit tests


// Just a public enumerated type; See TriangleType.java

public enum Triangle {
   SCALENE, ISOSCELES, EQUILATERAL, INVALID
}





