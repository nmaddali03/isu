#include "Ball.h"

Ball::Ball(double y, double x, int speed)
{
    setY(y);
    setX(x);
    setSpeed(speed);
}