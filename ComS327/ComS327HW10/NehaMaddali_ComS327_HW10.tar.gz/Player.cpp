#include "Player.h"

Player::Player(int y, int x)
{
    setX(x);
    setY(y);
}