#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#define USER_LOG
#include "kernel/schedlog.h"

// Define the names of scheduling states
static char *sched_states[] = {
    [UNUSED] "UNUSED",
    [SLEEPING] "SLEEPING",
    [RUNNABLE] "RUNNABLE",
    [RUNNING] "RUNNING",
    [ZOMBIE] "ZOMBIE"
};

// Function to busy-wait and consume CPU time
void consumeCPUTime() {
    volatile int calc = 0;
    for (int i = 0; i < 100000; i++) {
        for (int j = 0; j < 10000; j++) {
            calc += i;
        }
    }
}

int main(int argc, char *argv[]) {
    int pid;
    int status = 0;
    int nice_values[] = {14, 19}; // Nice values for the two test cases
    struct logentry schedlog[SCHED_LOG_SIZE];

    int child_pids[2]; // Array to store child process PIDs

    // Initialize the scheduling log array
    for (int i = 0; i < SCHED_LOG_SIZE; i++) {
        schedlog[i].pid = -1;
    }

    // Test 1: Two CPU-bound processes with different nice values
    printf("Test 1: Two CPU-bound processes with different nice values:\n");
    for (int i = 0; i < 2; i++) {
        pid = fork();
        if (pid < 0) {
            printf("fork() failed\n");
            exit(1);
        } else if (pid == 0) {
            // Child process
            int nice_val = nice_values[i];
            nice(nice_val); // Set the nice value for the child process

            // Consume some CPU time
            consumeCPUTime();
            exit(0);
        } else {
            child_pids[i] = pid; // Store the child process PID
        }
    }

    // Wait for the first two child processes to finish
    for (int i = 0; i < 2; i++) {
        wait(&status);
    }

    // Get the scheduling log
    int getlog_result = getlog(schedlog);
    if (getlog_result < 0) {
        printf("getlog() failed\n");
        exit(1);
    }

    // Print the scheduling log
    for (int i = 0; i < SCHED_LOG_SIZE; i++) {
        if (schedlog[i].pid != -1) {
            printf("pid=%d, fromstate=%s, tostate=%s, time=%d\n",
                   schedlog[i].pid,
                   sched_states[schedlog[i].fromstate],
                   sched_states[schedlog[i].tostate],
                   schedlog[i].time);
        }
    }

    // Print runtime results for both child processes
    for (int i = 0; i < 2; i++) {
        int runtime = getruntime(child_pids[i]);
        printf("Child %d (PID %d) runtime: %d ticks\n", i + 1, child_pids[i], runtime);
    }

    // Test 2: One CPU-bound process and one I/O-bound process
    printf("\nTest 2: One CPU-bound process and one I/O-bound process:\n");
    for (int i = 0; i < 2; i++) {
        pid = fork();
        if (pid < 0) {
            printf("fork() failed\n");
            exit(1);
        } else if (pid == 0) {
            // Child process
            int nice_val = nice_values[i];
            nice(nice_val); // Set the nice value for the child process

            if (i == 0) {
                // Consume some CPU time
                consumeCPUTime();
            } else {
                // Simulate I/O-bound by sleeping for seconds (adjust the count as needed)
                for (uint64 j = 0; j < 100; j++) {
                    sleep(1); // Sleep for 1 tick (adjust the value based on your tick rate)
                }
            }
            exit(0);
        } else {
            child_pids[i] = pid; // Store the child process PID
        }
    }

    // Wait for both child processes to finish
    for (int i = 0; i < 2; i++) {
        wait(&status);
    }

    // Print runtime results for both child processes
    for (int i = 0; i < 2; i++) {
        int runtime = getruntime(child_pids[i]);
        printf("Child %d (PID %d) runtime: %d ticks\n", i + 1, child_pids[i], runtime);
    }

    exit(0);
}
