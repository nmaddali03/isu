#include <stdio.h>
#include "journal.h"
#include <pthread.h>
#include <semaphore.h>

// Number of threads for project requirements
#define NUM_THREADS 3
int sleeper = 0;

//circular buffer structure
typedef struct
{
	struct write_request *buffer[BUFFER_SIZE];
	int head;
	int tail;
	int size;
} circ_buff_t;

circ_buff_t requestBuffer;
circ_buff_t metaDataBuffer;
circ_buff_t commitCompletedBuffer;

//sempahores and mutexes for synchronization
sem_t mutex;
sem_t requestBufferHasSpaceMutex;
sem_t requestBufferNotEmptyMutex;
sem_t metaDataBufferHasSpaceMutex;
sem_t metaDataBufferNotEmptyMutex;
sem_t commitCompletedBufferHasSpaceMutex;
sem_t commitCompletedBufferNotEmptyMutex;

//thread identifiers
pthread_t metaDataThread;
pthread_t journalCommitWriteThread;
pthread_t checkpointThread;

// function to enqueue a write request in the circular buffer
int enqueue(circ_buff_t *currBuffer, struct write_request *wr)
{
	//calculate the next head position in the circular buffer
	int nextHead = currBuffer->head + 1; 
	if (nextHead >= BUFFER_SIZE)
	{
		nextHead = 0; //wrap to beginning if the buffer is full
	}

	//store the write request at the current head position
	currBuffer->buffer[currBuffer->head] = wr; 
	currBuffer->head = nextHead;
	//increment the size of the buffer			   
	currBuffer->size++;
}

//function to dequeue to write request from the circular buffer
struct write_request *dequeue(circ_buff_t *currBuffer)
{
	//calculate the next tail position in the circular buffer
	int nextTail;
	nextTail = currBuffer->tail + 1;
	if (nextTail >= BUFFER_SIZE)
	{
		//wrap around to beginning if the buffer is full
		nextTail = 0;
	}
	//retrieve the write request at the current tail position
	struct write_request *wr = currBuffer->buffer[currBuffer->tail];
	//update the tail position
	currBuffer->tail = nextTail;
	//decrement the size of the buffer
	currBuffer->size--;
	//return the dequeued write request
	return wr;
}

//thread 1: metadata write
void *metaDataWrite()
{
	while (1)
	{
		//wait until there are write requests in the request buffer
		sem_wait(&requestBufferNotEmptyMutex);
		sem_wait(&mutex);
		printf("Thread 1 processing %d %d %d\n", requestBuffer.size, metaDataBuffer.size, commitCompletedBuffer.size);

		//dequeue a write request from the request buffer
		struct write_request *wr = dequeue(&requestBuffer);

		//process the write request: issue writes to data, txb, bitmap, and inode
		issue_write_data(wr->data, wr->data_idx);
		issue_journal_txb();
		issue_journal_bitmap(wr->bitmap, wr->bitmap_idx);
		issue_journal_inode(wr->inode, wr->inode_idx);

		//release the mutex and signal that space is available in the request buffer
		sem_post(&mutex);
		sem_post(&requestBufferHasSpaceMutex);

		//check if the metadata buffer is full and print a message if so
		if (metaDataBuffer.size >= 7)
		{
			printf("*Thread stuck because of full buffer* %d, %d, %d\n", requestBuffer.size, metaDataBuffer.size, commitCompletedBuffer.size);
		}
		
		//wait until there is space in the metadata buffer
		sem_wait(&metaDataBufferHasSpaceMutex);
		sem_wait(&mutex);

		//enqueue the processed write request into the metadata buffer
		enqueue(&metaDataBuffer, wr);

		//signal that the metadata buffer is not empty
		sem_post(&metaDataBufferNotEmptyMutex);
		sem_post(&mutex);
	}
}

int hasPrintedBlock = 0;
//thread 2: journal commit
void *journalCommit()
{
	while (1)
	{
		//wait until there are processed write requests in the metadata buffer
		sem_wait(&metaDataBufferNotEmptyMutex);
		sem_wait(&mutex);
		printf("Thread 2 processing %d %d %d\n", requestBuffer.size, metaDataBuffer.size, commitCompletedBuffer.size);

		//dequeue a processed write request from the metadata buffer
		struct write_request *wr = dequeue(&metaDataBuffer);

		//check if its the first processed block and print a blocking message
		if (hasPrintedBlock == 0)
		{
			printf("Blocking thread by sleeping for 1s\n");
			hasPrintedBlock++;
		}

		//issue the journal transaction end (txe)
		issue_journal_txe();

		//release the mutex and signal that there is space in the metadata buffer
		sem_post(&mutex);
		sem_post(&metaDataBufferHasSpaceMutex);

		//check if the commit completed buffer is full and print a message if so
		if (commitCompletedBuffer.size >= 7)
		{
			printf("*Thread stuck because Commit Completed buffer is full* %d, %d, %d\n", requestBuffer.size, metaDataBuffer.size, commitCompletedBuffer.size);
		}

		//wait until there is space in the commit completed buffer
		sem_wait(&commitCompletedBufferHasSpaceMutex);
		sem_wait(&mutex);

		//enqueue the processed write request into the commit completed buffer
		enqueue(&commitCompletedBuffer, wr);

		//release the mutex and signal that the commit completed buffer is not empty
		sem_post(&mutex);
		sem_post(&commitCompletedBufferNotEmptyMutex);
	}
}

//thread 3: journal commit complete
void *journalCommitComplete()
{
	while (1)
	{
		//wait until there are processed write requests in the commit completed buffer
		sem_wait(&commitCompletedBufferNotEmptyMutex);
		sem_wait(&mutex);
		printf("Thread 3 processing %d %d %d\n", requestBuffer.size, metaDataBuffer.size, commitCompletedBuffer.size);

		//dequeue a processed write request from the commit completed buffer
		struct write_request *wr = dequeue(&commitCompletedBuffer);

		//issue write operations for bitmap and inode
		issue_write_bitmap(wr->bitmap, wr->bitmap_idx);
		issue_write_inode(wr->inode, wr->inode_idx);

		//release the mutex and signal that there is space in the commit completed buffer
		sem_post(&mutex);
		sem_post(&commitCompletedBufferHasSpaceMutex);

		//notify the file system that the write is complete
		write_complete();
	}
}

/* This function can be used to initialize the buffers and threads.
 */
void init_journal()
{
	sem_init(&mutex, 0, 1);
	sem_init(&requestBufferHasSpaceMutex, 0, 8);
	sem_init(&requestBufferNotEmptyMutex, 0, 0);
	sem_init(&metaDataBufferHasSpaceMutex, 0, 8);
	sem_init(&metaDataBufferNotEmptyMutex, 0, 0);
	sem_init(&commitCompletedBufferHasSpaceMutex, 0, 8);
	sem_init(&commitCompletedBufferNotEmptyMutex, 0, 0);

	pthread_create(&metaDataThread, NULL, metaDataWrite, NULL);
	pthread_create(&journalCommitWriteThread, NULL, journalCommit, NULL);
	pthread_create(&checkpointThread, NULL, journalCommitComplete, NULL);
}

/* This function is called by the file system to request writing data to
 * persistent storage.
 *
 * This is the non-thread-safe solution to the problem. It issues all writes in
 * the correct order, but it doesn't wait for each phase to complete before
 * beginning the next. As a result the journal can become inconsistent and
 * unrecoverable.
 */
void request_write(struct write_request *wr)
{
	/*
		// write data and journal metadata
	issue_write_data(wr->data, wr->data_idx);
	issue_journal_txb();
	issue_journal_bitmap(wr->bitmap, wr->bitmap_idx);
	issue_journal_inode(wr->inode, wr->inode_idx);
	// commit transaction by writing txe
	issue_journal_txe();
	// checkpoint by writing metadata
	issue_write_bitmap(wr->bitmap, wr->bitmap_idx);
	issue_write_inode(wr->inode, wr->inode_idx);
	// tell the file system that the write is complete
	write_complete();
	*/

	//enqueue the write request to the circular buffer for processing by the threads
	sem_wait(&requestBufferHasSpaceMutex);
	sem_wait(&mutex);
	enqueue(&requestBuffer, wr);
	sem_post(&mutex);
	sem_post(&requestBufferNotEmptyMutex);
}

/* This function is called by the block service when writing the txb block
 * to persistent storage is complete (e.g., it is physically written to disk).
 */
void journal_txb_complete()
{
	printf("journal txb complete\n");
}

void journal_bitmap_complete()
{
	printf("journal bitmap complete\n");
}

void journal_inode_complete()
{
	printf("journal inode complete\n");
}

void write_data_complete()
{
	printf("write data complete\n");
}

void journal_txe_complete()
{
	printf("journal txe complete\n");
}

void write_bitmap_complete()
{
	printf("write bitmap complete\n");
}

void write_inode_complete()
{
	printf("write inode complete\n");
}